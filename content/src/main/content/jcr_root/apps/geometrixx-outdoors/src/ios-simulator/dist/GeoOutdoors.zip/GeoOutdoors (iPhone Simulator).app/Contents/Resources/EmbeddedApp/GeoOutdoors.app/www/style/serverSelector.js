/*
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2012 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */

function ServerSelector(selectorContainerId) {

    // Path to the GeoOutdoors mobile English page
    var geoOutdoorsMobileEnPath = "content/geometrixx-outdoors-mobile/en.html";
    // Array of server URLs
    var serverUrls = null;
    // Flag to indicate if we've loaded existing servers from localStorage
    var serverHistoryLoaded = false;
    // Server selector container DOM ID
    var selectorContainerId = selectorContainerId;
    // URI's with this protocol will invoke this app
    var APP_PROTOCOL = "cqshell://";

    this.handleProtocolRequest = function(invokeString) {
        // Sanity
        if (invokeString === null || invokeString.length < (APP_PROTOCOL.length + 1)) {
            return;
        }

        // Hide server selection dialog
        $("div#makeAServerSelection").css("visibility", "hidden");

        populateServersFromLocalStorage();

        // Remove the protocol handler prefix
        invokeString = invokeString.substring(APP_PROTOCOL.length);

        persistAndNavigateToHost(invokeString);
    };

    this.redirectToLocalhostIfAvailable = function () {
        var localPublishGeoUrl = "http://localhost:4503/" + geoOutdoorsMobileEnPath;
        // Request the head and check for an error
        $.ajax({
            url: localPublishGeoUrl,
            type: 'HEAD',
            error:
                function(){
                    // Local publish is unavailable; show the server selector.
                    initializeServerSelector();
                },
            success:
                function(){
                    // Redirect to local publish
                    window.location = localPublishGeoUrl;
                }
        });
    };

    /**
     * Initializes the server selector component. Populates the dropdown with
     * all servers previously entered (if localStorage is supported).
     */
    function initializeServerSelector() {
        // Assign change handler to server selector
        $("#serverSelector").change(serverSelectionChanged);
        // Button to enable user to navigate back to the server selector
        $("#hideAddUrl").on("click", backToServerSelector);
        // Save and navigate to a new server URL
        $("#goToUrl").on("click", goToUrl);

        populateServersFromLocalStorage();

        // Show the selector
        $("#"+selectorContainerId).slideDown();
    }

    function populateServersFromLocalStorage() {
        // If we've already loaded the saved servers, don't do it again
        if (serverHistoryLoaded) {
            return;
        }
        serverHistoryLoaded = true;

        if (false == supportsHtml5Storage()) {
            return;
        }

        // Retrieve saved server URLs from local storage
        var stringifiedServerUrls = localStorage['serverUrls'];
        if (stringifiedServerUrls == null) {
            // No saved URLs; return
            return;
        }

        // We have some saved URLs
        serverUrls = JSON.parse(stringifiedServerUrls);
        var $newOption = null;
        serverUrls.forEach(function(url) {
            $newOption = $("<option></option>").html(url);
            $("#serverSelector").prepend( $newOption );
        });
    }

    function goToUrl() {
        var newServerUrl = $("#newServer").val();
        persistAndNavigateToHost(newServerUrl);
    }

    function persistAndNavigateToHost(hostName) {
        // Sanity
        if (hostName === null || hostName.length < 1) {
            return;
        }

        // Add http:// prefix if needed
        if (hostName.length < 8 ||
            ("http://" !== hostName.substring(0,7)) && "https://" !== hostName.substring(0,8)) {
            hostName = "http://" + hostName;
        }

        // Add trailing / if needed
        if (hostName.charAt(hostName.length - 1) != '/') {
            hostName = hostName + '/';
        }

        // If localStorage is supported, persist the array of URLs before forwarding
        if (supportsHtml5Storage()) {
            if (serverUrls === null) {
                serverUrls = [];
            }

            if ($.inArray(hostName, serverUrls) === -1) {
                // Only add the new server if it does not already exist
                serverUrls[serverUrls.length] = hostName;
                localStorage['serverUrls'] = JSON.stringify(serverUrls);
            }
        }

        forwardToServer(hostName);
    }

    // Attempts to forward the app to the GeoOutdoors mobile English page on the given server
    function forwardToServer(serverUrl) {
        window.location = serverUrl + geoOutdoorsMobileEnPath;
    }

    function serverSelectionChanged() {
        var $selectedOption = $(this).find("option:selected");
        if ("instructions" === $selectedOption.attr("id")) {
            return;
        }

        if ("addServer" === $selectedOption.attr('id')) {
            // De-select this option
            $selectedOption.removeAttr("selected");
            $("#makeAServerSelection").slideUp(function() {
                // Slide is complete
                $("#enterANewServer").slideDown();
            });
        }
        else {
            // navigate to the selected server
            var serverAndPort = $selectedOption.text();
            forwardToServer(serverAndPort);
        }
    }

    function backToServerSelector() {
        $("#enterANewServer").slideUp(function() {
            // Slide is complete
            $("#makeAServerSelection").slideDown();
        });
    }

    // Detect if localStorage is supported by this client
    function supportsHtml5Storage() {
        try {
            return 'localStorage' in window && window['localStorage'] !== null;
        } catch (e) {
            return false;
        }
    }
}